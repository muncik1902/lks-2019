<!DOCTYPE html>
<html>
<head>
	<link rel="shortcut icon" type="text/css" href="img/logo.png">
	<title></title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
</head>
<body>

	<div class="container-fluid" style="background-color: white; padding-top: 20px;">
		<div class="row justify-content-center">
			<p class="text-center" style="font-size: 18px; letter-spacing: 2px;">Copyright &copy STMIK Widya Pratama <br> ALL Rights Reserved.</p>
		</div>
	</div>

</body>
</html>