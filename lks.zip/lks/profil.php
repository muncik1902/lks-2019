<!DOCTYPE html>
<html>
<head>
	<title>Profil</title>
	<link rel="shortcut icon" type="text/css" href="img/logo.png">

	<style type="text/css">
		.jumbotron {
			background-image: url('img/gambar_slider/05.jpg');
			height: 540px;
			background-size: cover;
			position: relative;
			text-align: center;
		}

		.jumbotron .container {
			position: relative;
			z-index: 1;
		}

		.jumbotron::after {
			content: '';
			display: block;
			width: 100%;
			height: 100%;
			background-image: linear-gradient(to top, rgba(0,0,0,1), rgba(0,0,0,0));
			position: absolute;	
			bottom: 0;
		}

		hr {
			border-top: 2px solid grey !important;
		}

		.visi {
			background-color: #001c4f;
			height: 400px;
			padding: 20px !important;
			}

		.misi {
			background-color: salmon;
			height: 400px;
			padding: 20px !important;
		}

		.abs img {
				height: 400px; 
				width: 200px; 
				position: relative;
				margin-left: -60px;
				opacity: 3;
		}

		.jumbotron h3 {
    		
    		font-weight: 100;
    		font-size: 30px;
    		color: white !important;
    		margin-top: 50px;
    		text-shadow: 2px 2px 2px rgba(0,0,0,0.7);
    		margin-bottom: 50px;
    		
    	}

    	.bagan img {
    		width: 450px;
    		height: 300px;
    		margin: auto;
    	}

    	.sejarah {
    		padding: 100px;
    		padding-top: 30px !important;
    		padding-bottom: 30px !important;
    	}

		@media (min-width: 992px) {

			.jumbotron {
				height: 640px;
				
			}

			.jumbotron::after {
				content: '';
				display: block;
				width: 100%;
				height: 200%;
				background-image: linear-gradient(to top, rgba(0,0,0,1), rgba(0,0,0,0));
				position: absolute;
				bottom: 0;
			}
			.abs img {
				height: 300px; 
				width: 500px; 
				position: relative;
			}

			.jumbotron h3 {
    			font-weight: 200;
    			font-size: 35px;
    			letter-spacing: 5px;
    		}

    		.visi {
			background-color: #001c4f;
			height: 400px;
			padding: 100px !important;
			}

			.misi {
			background-color: salmon;
			height: 400px;
			padding: 40px !important;
			}

			.bagan img {
				width: 100%;
				height: 500px;
			}
		}
	</style>
</head>
<body>
	<?php include 'navigasi.php'; ?>

	<div class="jumbotron jumbotron-fluid">
		<div class="container">
			<p class="text-center"><img class="" src="img/logo.png" style="width: 150px; height: 150px; margin-top: 50px;"></p>
			<h3 class="intro text-center">Sekolah Tinggi Manajemen Informatika dan Komputer</h3>
			<p class="text-white text-center" style="font-size: 18px; letter-spacing: 2px;">Jl. Patriot No.25, Dukuh, Kec. Pekalongan Utara, Kota Pekalongan, Jawa Tengah 51146</p>
		</div>
	</div>

	<div class="container">
		<h3 class="text-center text-grey">Sejarah</h3>
		<hr>
		<div class="row " >
			<div class="col-lg-12 sejarah" style="">
				<img class="float-left" src="img/logo.png" style="width: 100px; height: 100px; margin-right: 30px;">
				<p>Sekolah Tinggi Manajemen Informatika dan Komputer (STMIK) Widya Pratama di Pekalongan berdiri tahun 2002 berdasarkan SK Mendiknas Nomor : 149/D/O/2002 yang diselenggarakan oleh Yayasan Pendidikan Widya Pratama di Pekalongan. Dalam surat keputusan tersebut STMIK Widya Pratama diberikan ijin untuk menyelenggarakan pendidikan Program Studi Sistem Informasi dan Program Studi Teknik Informatika untuk jenjang program strata 1 (S1)</p>
				<p>Namun, sebelumnya Yayasan Pendidikan Widya Pratama di Pekalongan telah mendapatkan kepercayaan dari pemerintah melalui Menteri Pendidikan dan Kebudayaan Indonesia untuk menyelenggarakan Akademi Manajemen Informatika dan Komputer (AMIK) Widya Pratama di Pekalongan. </p>
				<button class="btn btn-outline-success">Baca Selengkapnya <i class="fas fa-angle-double-right ml-2"></i></button>
			</div>
		</div>
		<hr>
	</div>

	<div class="container-fluid" style="padding-top: 30px;">
		<div class="row">
			<div class="col-lg-6 visi">
				<h3 class="text-white text-center">VISI</h3>
				<p class="text-white" style=" margin-top: 20px; letter-spacing: 2px;">
					Menjadi perguruan tinggi yang memiliki wawasan global dalam bidang teknologi informasi, menerapkan ilmu pengetahuan dan teknologi yang mendukung nilai-nilai keunggulan lokal tahun 2030
				</p>
			</div>
			<div class="col-lg-6 misi">
				<h3 class="text-white text-center">MISI</h3>
				<p class="text-white" style="letter-spacing: 2px; margin-top: 20px;">
					<i class="fas fa-circle mr-2"></i>Melaksanakan tridharma perguruan tinggi yang berkualitas dalam bidang Teknologi Informasi <br>
					<i class="fas fa-circle mr-2"></i>Menjalankan tatakelola institusi yang kredibel, trasparan, akuntabel, bertanggungjawab dan adil <br>
					<i class="fas fa-circle mr-2"></i>Menjalin kerjasama strategis yang berkelanjutan dengan stakeholder <br>
					<i class="fas fa-circle mr-2"></i>Meningkatkan citra intitusi sebagai perguruan tinggi yang terdepan dalam penguasaan IPTEKS yang mendukung nilai-nilai keunggulan lokal <br>

				</p>
			</div>
		</div>		
	</div>

	<div class="container" style="padding-top: 30px;">
		<h3 class="text-center text-grey">Struktur Organisasi</h3>
		<hr>
		<div class="row">
			<div class="col-lg-12 bagan">
				<img src="img/struktur-organisasi.jpg" style="">
			</div>
		</div>
		<hr>
	</div>
	<?php include 'footer.php' ?>
</body>
</html>