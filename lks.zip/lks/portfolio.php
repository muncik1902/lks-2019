<!DOCTYPE html>
<html>
<head>
	<title>Portfolio</title>
	<link rel="shortcut icon" type="text/css" href="img/logo.png">
	<style type="text/css">
		.galeri	{
			margin-top: 100px;
		}

		.hr {
			border-top: 2px solid grey !important;
		}

		.galeri img {
			width: 200px;
			height: 150px;
			margin: 10px;
			position: relative;
			z-index: 1;
		}

		.galeri img::hover::after {
			content: '';
			width: 100%;
			height: 80;
			background-image: linear-gradient(to top, rgba(0,0,0,1), rgba(0,0,0,0));
			position: absolute;
			bottom: 0;

		}

		@media (min-width: 992px) {
			.galeri img {
			width: 350px;
			height: 300px;
			margin: 10px;
			}
		}

	</style>
</head>
<body>
	<?php include 'navigasi.php'; ?>
	<div class="container galeri">
		<div class="row">
			<div class="col-lg-12" style="">
				<h3 class="text-center text-grey" style="text-transform: uppercase;">Portfolio</h3>
				<hr>
				<div class="gambar" style="">
					<img class="float-left thumbnail" src="img/gambar_berita/01.jpg"></img>
					<img class="float-left thumbnail" src="img/gambar_berita/02.jpg"></img>
					<img class="float-left thumbnail" src="img/gambar_berita/03.jpg"></img>
					<img class="float-left thumbnail" src="img/gambar_berita/04.jpg"></img>
					<img class="float-left thumbnail" src="img/gambar_berita/05.jpg"></img>
					<img class="float-left thumbnail" src="img/gambar_berita/01.jpg"></img>
				</div>
			</div>
		</div>
		<hr>
		<p class="text-center pt-2 pb-2" >
			<button type="button" class="btn btn-secondary">1</button>
			<button type="button" class="btn btn-secondary">2</button>
			<button type="button" class="btn btn-secondary">3</button>						
			<button type="button" class="btn btn-secondary"><i class="fas fa-angle-double-right"></i></button>						
		</p>
	</div>
	<?php include 'footer.php'; ?>
</body>
</html>