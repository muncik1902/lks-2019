<!DOCTYPE html>
<html>
<head>
	<link rel="shortcut icon" type="text/css" href="img/logo.png">
	<title></title>

	<style type="text/css">
		.navbar-brand {
			font-family: helvetica;
			font-weight: bold;
			font-size: 25px !important;
		}

		.navbar-brand, .nav-link {
			color: white !important;
		}

		.nav-link {
			margin-left: 15px;
		}

		.text-grey {
			color: grey;
		}

		hr {
			border-top: 2px solid grey !important;
		}
	</style>
</head>
<body>
	<?php include 'library.php'; ?>

	<nav class="navbar navbar-expand-lg navbar-light bg-dark fixed-top">
		<div class="container">
		  <a class="navbar-brand" href="#"><img class="mr-3" src="img/logo.png" style="width: 50px; height: 50px; margin-top: -10px;">STMIK WIDYA PRATAMA</a>
		  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#NAVBAR" aria-controls="NAVBAR" aria-expanded="false" aria-label="Toggle navigation">
		    <span class="navbar-toggler-icon"></span>
		  </button>
		  <div class="collapse navbar-collapse" id="NAVBAR">
		    <div class="navbar-nav ml-auto">
		      <a class="nav-item nav-link active" href="beranda.php"><i class="fa fa-home mr-2"></i>Beranda</span></a>
		      <a class="nav-item nav-link" href="informasi.php"><i class="fas fa-newspaper mr-2"></i>Informasi</a>
		      <a class="nav-item nav-link" href="profil.php"><i class="fas fa-info-circle mr-2"></i>Profil</a>
		      <a class="nav-item nav-link" href="fasilitas.php"><i class="fas fa-university mr-2"></i>Fasilitas</a>
		      <a class="nav-item nav-link" href="portfolio.php"><i class="fas fa-photo-video mr-2"></i>Portfolio</a>
		      <button class="nav-link btn btn-outline-success" type="button" data-toggle="modal" data-target="#modal" style="padding-right: 15px; padding-left: 15px;">Masuk</button>
		    </div>
		  </div>
		</div>
	</nav>

	<div class="modal" id="modal" tabindex="-1" role="dialog">
	  <div class="modal-dialog" role="document">
	    <div class="modal-content">
	      <div class="modal-header">
	        <h5 class="modal-title">Masuk</h5>
	        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
	          <span aria-hidden="true">&times;</span>
	        </button>
	      </div>
	      <div class="modal-body">
	      	<form>
			  <div class="form-group">
			    <label for="username">Username</label>
			    <input type="email" class="form-control" id="username" placeholder="Masukkan Username">
			  </div>
			  <div class="form-group">
			    <label for="password">Password</label>
			    <input type="password" class="form-control" id="password" placeholder="Masukkan Password">
			  </div>
			  <div class="form-group">
			    <label for="pilih">Masuk Sebagai</label>
			    <select class="form-control" id="pilih">
			      <option>Dosen</option>
			      <option>Mahasiswa</option>
			    </select>
			  </div>
			  <div class="form-group form-check">
			    <input type="checkbox" class="form-check-input" id="ingatsaya">
			    <label class="form-check-label" for="ingatsaya">Ingat Saya</label>
			  </div>
			  <button type="submit" class="btn btn-primary">Masuk</button>
			  <a class="text-grey ml-2" href="">Lupa Password?</a>
			</form>	        
	      </div>
	    </div>
	  </div>
	</div>

</body>
</html>