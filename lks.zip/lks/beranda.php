<!DOCTYPE html>
<html>
<head>
	<link rel="shortcut icon" type="text/css" href="img/logo.png">
	<title>Beranda</title>

	<style type="text/css">
		.jumbotron {
			background-image: url('img/gambar_slider/05.jpg');
			height: 540px;
			background-size: cover;
			position: relative;
			text-align: center;
		}

		.jumbotron .container {
			position: relative;
			z-index: 1;
		}

		.jumbotron h3 {
    		
    		font-weight: 100;
    		font-size: 30px;
    		color: white !important;
    		margin-top: 120px;
    		text-shadow: 2px 2px 2px rgba(0,0,0,0.7);
    		margin-bottom: 70px;
    		
    	}

    	.jumbotron h3 span {
    			font-weight: 200;
    			font-size: 50px;
    			color: salmon;
    	}

    	.card {
    		box-shadow: 3px 3px 3px rgba(0,0,0,0.4);
    	}

    	.jumbotron::after {
				content: '';
				display: block;
				width: 100%;
				height: 100%;
				background-image: linear-gradient(to top, rgba(0,0,0,1), rgba(0,0,0,0));
				position: absolute;		
				bottom: 0;
			}

		.hr {
			border-top: 5px solid grey !important;
			margin-bottom: 50px;
		}

		.kontak p {
			font-size: 20px;
		}



		@media (min-width: 992px) {
			.jumbotron {
				height: 640px;
			}

			.jumbotron::after {
				content: '';
				display: block;
				width: 100%;
				height: 200%;
				background-image: linear-gradient(to top, rgba(0,0,0,1), rgba(0,0,0,0));
				position: absolute;		
				bottom: 0;
			}

			.jumbotron h3 {
    			font-weight: 200;
    			font-size: 40px;
    			letter-spacing: 5px;
    		}

    		.jumbotron h3 span {
    			font-weight: 400;
    			font-size: 60px;
    		}
    		.abstrak {
    			padding: 100px;
    			text-align: center;
    		}
		}
	</style>
</head>
<body>
	<?php include 'navigasi.php'; ?>
	<!-- jumbotron -->
	<div class="jumbotron jumbotron-fluid">
		<div class="container">
			<h3 class="sambutan">SELAMAT DATANG DI WEBSITE<br><span class="display-4">STMIK WIDYA PRATAMA</span><br>PEKALONGAN</h3>
    		<a href=""><i class="fas fa-angle-down text-white" style="font-weight: 20; width: 100px; height: 80px;"></i></a>
		</div>
	</div>
	<!-- end -->

	<div class="container">
		<div class="row justify-content-center">
			<div class="col-lg-10">
				<div class="card" style="padding: 20px; margin-top: -120px;">
					<div class="card-body">
						<img class="float-left rounded-circle" src="img/logo.png" style="width: 150px; height: 150px; margin-right: 20px;"></img>
						<p style="font-size: 16px; letter-spacing: 2px; margin-top: 30px;">
							Sekolah Tinggi Manajemen Informatika dan Komputer (STMIK) Widya Pratama di Pekalongan berdiri tahun 2002 berdasarkan SK Mendiknas Nomor : 149/D/O/2002 yang diselenggarakan oleh Yayasan Pendidikan Widya Pratama di Pekalongan.
						</p>
					</div>
				</div>
			</div>		
		</div>
	</div>

	<!-- end -->
		<div class="container-fluid">
			<div class="row">
				<div class="col-lg-12 abstrak" style="padding: 20px;">
					<p style="font-size: 16px; letter-spacing: 2px;">Program studi yang pertama kali diberikan ijin pengelenggaraan pendidikan adalah Program Studi Manajemen Informatika dengan status terdaftar berdasarkan SK Mendikbud Nomor: 157/D/O/1995. Pada tahun 1997, AMIK Widya Pratama Pekalongan menambah satu jurusan yaitu Komputerisasi Akuntansi dengan status terdaftar berdasarkan persetujuan dari Dirjen Dikti dengan SK Nomor: 173/DIKTI/Kep/1997. Sebagai salah satu bentuk pertanggungjawaban kepada pemerintah dan masyarakat maka AMIK Widya Pratama di Pekalongan menaikkan status dari terdaftar ke status disamakan untuk jurusan Manajemen Informatika</p>
				</div>
			</div>
		</div>

	<!-- end -->

	<div class="container-fluid">
		<div class="row kotak">
			<div class="col-lg-6 mr-auto text-center" style="background-color: #032751; height: 400px; padding: 30px;">
				<p class="text-white" style="margin-top: 80px; font-size: 32px; font-weight: bold; text-shadow: 3px 3px 3px rgba(0,0,0,0.7);">Penerimaan Mahasiswa Baru <br> Tahun Ajaran 2019/2020</p>
				<button class="btn btn-outline-light" style="box-shadow: 3px 3px 3px rgba(0,0,0,0.7);">Detail <i class="fas fa-angle-double-right ml-2"></i></button>
			</div>
			<div class="col-lg-6 ml-auto" style="height: 400px; background-image: url('img/gambar_slider/03.png'); background-size: cover;"></div>			
		</div>

		<div class="row">
			<div class="col-lg-6 mr-auto" style="height: 400px; background-image: url('img/gambar_slider/01.png'); background-size: cover; "></div>
			<div class="col-lg-6 mr-auto text-center" style="background-color: #032751; height: 400px; padding: 30px;">
				<p class="text-white" style="margin-top: 80px; font-size: 32px; font-weight: bold; text-shadow: 3px 3px 3px rgba(0,0,0,0.7);">Akreditasi B <br>Program Studi Komputerisasi <br>Akuntansi</p>
				<button class="btn btn-outline-light" style="box-shadow: 3px 3px 3px rgba(0,0,0,0.7);">Detail <i class="fas fa-angle-double-right ml-2"></i></button>
			</div>
						
		</div>
	</div>
	<hr>

	<div class="container">
			<div class="row">
				<div class="col-lg-12 abstrak" style="padding: 20px;">
					<h3 class="text-grey">Sambutan Kepala STMIK Widya Pratama</h3>
					<p style="font-size: 16px; letter-spacing: 2px;">Program studi yang pertama kali diberikan ijin pengelenggaraan pendidikan adalah Program Studi Manajemen Informatika dengan status terdaftar berdasarkan SK Mendikbud Nomor: 157/D/O/1995. Pada tahun 1997, AMIK Widya Pratama Pekalongan menambah satu jurusan yaitu Komputerisasi Akuntansi dengan status terdaftar berdasarkan persetujuan dari Dirjen Dikti dengan SK Nomor: 173/DIKTI/Kep/1997. Sebagai salah satu bentuk pertanggungjawaban kepada pemerintah dan masyarakat maka AMIK Widya Pratama di Pekalongan menaikkan status dari terdaftar ke status disamakan untuk jurusan Manajemen Informatika</p>
				</div>
			</div>
		</div>
		<hr>

		<div class="container"">
			<div class="row" >
				<div class="col-lg-6 kontak" style="height: 300px;">
					<h3 class="text-grey" style="margin-bottom: 50px;">Hubungi Kami</h3>
					<p><i class="fab fa-facebook mr-3"></i>STMIK WIDYA PRATAMA</p>
					<p><i class="fab fa-twitter mr-3"></i>@stmikwp.id</p>
					<p><i class="fab fa-instagram mr-3"></i>@stmikpekalongan</p>
					<p><i class="fab fa-whatsapp mr-3"></i>0865 7286 8165</p>
				</div>

				<div class="col-lg-6" style="height: 300px;">
					<h3 class="text-grey" style="margin-bottom: 20px;">Struktur Organisasi</h3>
					<img class="thumbnail bordered" src="img/struktur-organisasi.jpg" style="width: 450px; height: 200px;">					
				</div>
		</div>
<hr>
		<?php include 'footer.php'; ?>

</body>
</html>