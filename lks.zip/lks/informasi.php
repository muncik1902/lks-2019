<!DOCTYPE html>
<html>
<head>
	<title>Informasi</title>
	<link rel="shortcut icon" type="text/css" href="img/logo.png">
	<style type="text/css">
		hr {
			border-top: 2px solid grey !important;
		}

		.berita img {
			width: 300px;
			height: 200px;
			margin-right: 30px;
		}

		.card {
			margin-bottom: 20px;
			box-shadow: 2px 2px 2px rgba(0,0,0,0.4);
		}

		.sambutan {
				padding: 50px;
			}

		@media ( min-width: 992px) {
			.sambutan {
				padding-top: 100px; 
				padding-bottom: 100px; 
				padding-left: 200px !important; 
				padding-right: 200px !important;
			}
		}

		
	</style>
</head>
<body>
	<?php include 'navigasi.php'; ?>

	<div class="container" style="margin-top: 60px;">
		<div class="row">
			<div class="col-lg-8">				
				<hr>
				<div class="berita" style="background-color: #032751; height: 50px;">
					<h3 class="text-center pt-2 pb-2 text-white" >Berita Terbaru</h3>
				</div>
				<hr>

				<div class="card">
					<div class="card-body berita">
						<h5 class="judul"><a href="">Pembekalan dan Pelepasan Mahasiswa Magang</a></h5>
						<img class="float-left" src="img/gambar_berita/01.jpg"></img>
						<p>Jumat, 30 Agustus 2019. STMIK Widya Pratama mengadakan kegiatan pembekalan dan pelepasan mahasiswa magang. Kegiatan magang merupakan mata kuliah yang wajib di tempuh di STMIK Widya Pratama. Pada acara tersebut dibuka oleh Ketua STMIK Widya Pratama Bapak Dicke JSH Siregar, M.Kom. Dalam sambutannya disampaikan bahwa agar mahasiswa magang dapat mematuhi peraturan dan tata tertib yang berlaku di dunia industri atau dunia kerja.</p>
						<p> Tujuan dari kegiatan magang ini adalah untuk mempersiapkan mahasiswa di dunia kerja. Kegiatan magang dilakukan selama satu semester di dunia industri. Harapannya dengan kegiatan tersebut, mahasiswa mampu menerapkan ilmu yang telah diperoleh di bangku kuliah untuk diditerapkan di dunia industri atau dunia usaha.</p>
						<button class="btn btn-outline-success">Baca Selengkapnya <i class="fas fa-angle-double-right ml-2"></i></button>						
					</div>
				</div>

				<div class="card">
					<div class="card-body berita">
						<h5 class="judul"><a href="">Pemenang Lomba Pekan Ilmiah</a></h5>
						<img class="float-left" src="img/gambar_berita/02.jpg"></img>
						<p>Salah satu agenda tahunan yang diadakan Unit P3M STMIK Widya Pratama Pekalongan adalah Pekan llmiah. Pekan Ilmiah 2019 telah sukses dilaksanakan. Selamat untuk para pemenang lomba.</p>
						<button class="btn btn-outline-success">Baca Selengkapnya <i class="fas fa-angle-double-right ml-2"></i></button>						
					</div>
				</div>

				<div class="card">
					<div class="card-body berita">
						<h5 class="judul"><a href="">Wisuda Sarjana dan Ahli Madia Gasal 2018/2019</a></h5>
						<img class="float-left" src="img/gambar_berita/03.jpg"></img>
						<p>Sekolah Tinggi Manajemen Informatik dan Komputer (STMIK Widya Pratama) memwisuda sebanyak 164 Mahasiswa, Rabu (3 Juli 2019), di Sahid International Convention Center Kota Pekalongan.  Ketua STMIK Widya Pratama, Dicke JSH Siregar, M.Kom memaparkan hal itu dalam kegiatan wisuda yang dihadiri oleh Pimipinan atau yang mewakili LLDIKTI Wilayah VI Jawa Tengah, Walikota Pekalongan atau yang mewakili, para orang tua wisudawan, serta beberapa tamu undangan lainnya.</p>
						<button class="btn btn-outline-success">Baca Selengkapnya <i class="fas fa-angle-double-right ml-2"></i></button>						
					</div>
				</div>

				<hr>
				<div class="berita " style="background-color: #032751; height: 52px;">
					<p class="text-center pt-2 pb-2" >
						  <button type="button" class="btn btn-secondary">1</button>
						  <button type="button" class="btn btn-secondary">2</button>
						  <button type="button" class="btn btn-secondary">3</button>
						  <button type="button" class="btn btn-secondary"><i class="fas fa-angle-double-right"></i></button>						
					</p>
				</div>
				<hr>
						
			</div>

			<div class="col-lg-4">
					<hr>
						<div class="berita" style="background-color: #032751; height: 50px;">
							<h3 class="text-center pt-2 pb-2 text-white" >Agenda</h3>
						</div>
					<hr>
					<div class="card">
						<div class="card-body berita">
							<h5 class="judul"><a href="">BEM STMIK Widya Pratama Selenggarakan INAGURASI MAHASISWA</a></h5>
							<img class="float-left" src="img/gambar_agenda/01.jpg"></img>
							<p>Bem STMIK Widya Pratama telah sukses menyelenggaran kegiatan INAGURASI MAHASISWA 2018 pada 22 September 2018. Kegiatan tersebut hadiri ribuan pengunjung baik dari STMIK Widya Pratama, maupun masyarkat sekitar. </p>

							<p>Penampilan NUFI WARDANA yang apik telah membius para pengunjung inagurasi. Grup band lokal juga ikut berpartisipasi pada kegiatan tersebut seperti "The Batagor", "Bluewhale", "Kharroz", dan "Tofu Circle"</p>
							<button class="btn btn-outline-success">Baca Selengkapnya <i class="fas fa-angle-double-right ml-2"></i></button>						
						</div>
					</div>

					<hr>
					<div class="berita " style="background-color: #032751; height: 52px;">
						<p class="text-center pt-2 pb-2" >
							  <button type="button" class="btn btn-secondary">1</button>
							  <button type="button" class="btn btn-secondary">2</button>
							  <button type="button" class="btn btn-secondary">3</button>
							  <button type="button" class="btn btn-secondary"><i class="fas fa-angle-double-right"></i></button>						
						</p>
					</div>
					<hr>
			</div>
		</div>
	</div>

	<div class="container-fluid sambutan" style="background-color: #641eba;">
		<img class="rounded-circle float-left" src="img/logo.png" style="width: 150px; height: 150px; margin-right: 30px;">
		<p class="text-white" style="margin-top: 20px;">
			Sekolah Tinggi Manajemen Informatika dan Komputer (STMIK) Widya Pratama di Pekalongan berdiri tahun 2002 berdasarkan SK Mendiknas Nomor : 149/D/O/2002 yang diselenggarakan oleh Yayasan Pendidikan Widya Pratama di Pekalongan. Dalam surat keputusan tersebut STMIK Widya Pratama diberikan ijin untuk menyelenggarakan pendidikan Program Studi Sistem Informasi dan Program Studi Teknik Informatika untuk jenjang program strata 1 (S1)
		</p>
		
	</div>



	<?php include 'footer.php'; ?>
</body>
</html>