<!DOCTYPE html>
<html>
<head>
	<link rel="shortcut icon" type="text/css" href="img/logo.png">
	<title>Fasilitas</title>

	<style type="text/css">
		.card {
			box-shadow: 3px 3px 3px rgba(0,0,0,0.4);
			margin-bottom: 20px;
		}

		
		.ikon {
			font-size: 60px;
		}
	</style>

</head>
<body>
	<?php include 'navigasi.php'; ?>

	<div class="container" style="margin-top: 100px;">
		<h3 class="text-center text-grey">Fasilitas</h3>
		<hr>
		<div class="row justify-content-center" >
			
			<div class="col-lg-4">
				<div class="card">
					<div class="card-body">
						<p class="text-center ikon"><i class="fas fa-desktop mr-3 text-center"></i></p>
						<h5 class="text-center">Lab Komputer</h5>
						<p class="jml text-center">8 Room</p>
					</div>
				</div>
			</div>

			<div class="col-lg-4">
				<div class="card">
					<div class="card-body">
						<p class="text-center ikon"><i class="fas fa-home mr-3 text-center"></i></p>
						<h5 class="text-center">Ruang Kelas</h5>
						<p class="jml text-center">13 Room</p>
					</div>
				</div>
			</div>

			<div class="col-lg-4">
				<div class="card">
					<div class="card-body">
						<p class="text-center ikon"><i class="fas fa-book mr-3 text-center"></i></p>
						<h5 class="text-center">Lab Bahasa</h5>
						<p class="jml text-center">4 Room</p>
					</div>
				</div>
			</div>
		</div>

		<div class="row justify-content-center" >
			
			<div class="col-lg-4">
				<div class="card">
					<div class="card-body">
						<p class="text-center ikon"><i class="fas fa-camera mr-3 text-center"></i></p>
						<h5 class="text-center">Studio WP TV</h5>
						<p class="jml text-center"> 1 Room</p>
					</div>
				</div>
			</div>

			<div class="col-lg-4">
				<div class="card">
					<div class="card-body">
						<p class="text-center ikon"><i class="fas fa-toilet mr-3 text-center"></i></p>
						<h5 class="text-center">Toilet</h5>
						<p class="jml text-center">6 Room</p>
					</div>
				</div>
			</div>

			<div class="col-lg-4">
				<div class="card">
					<div class="card-body">
						<p class="text-center ikon"><i class="fas fa-mosque mr-3 text-center"></i></p>
						<h5 class="text-center">Musholla</h5>
						<p class="jml text-center">2 Room</p>
					</div>
				</div>
			</div>
		</div>

		<hr>
	</div>
	<?php include 'footer.php'; ?>
</body>
</html>